
  <footer>
   <div class="footer-area">
      <div class="container">
         <div class="row xs-text-center">
            <div class="col-sm-5">
               <div class="footer-left">
            <ul class="social_icons">            
           
            <li class="facebook"><a href="<?php echo e(getcong_widgets('social_facebook')); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
            <li><a href="<?php echo e(getcong_widgets('social_twitter')); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
            <li><a href="<?php echo e(getcong_widgets('social_google')); ?>" target="_blank"><i class="fa fa-google"></i></a></li>
            <li><a href="<?php echo e(getcong_widgets('social_instagram')); ?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
            <li><a href="<?php echo e(getcong_widgets('social_pinterest')); ?>" target="_blank"><i class="fa fa-pinterest"></i></a></li>
            <li><a href="<?php echo e(getcong_widgets('social_vimeo')); ?>" target="_blank"><i class="fa fa-vimeo"></i></a></li>
            <li><a href="<?php echo e(getcong_widgets('social_youtube')); ?>" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
            
          </ul>  <p class="copyright-text"><?php if(getcong('site_copyright')): ?>
						
				<?php echo e(getcong('site_copyright')); ?>

			
			<?php else: ?>
			
				Copyright © <?php echo e(date('Y')); ?> <?php echo e(getcong('site_name')); ?>. All rights reserved.

			<?php endif; ?></p>
               </div>
            </div>
            <div class="col-sm-7">
               <div class="footer-right">
                  <ul class="pull-right footer-menu list-inline xs-no-float">
                     <li><a href="#">Home</a></li>
                     <li><a href="#">Mission</a></li>
                     <li><a href="#">Vision</a></li>
                     <li><a href="#">Team</a></li>
                     <li><a href="#">Contact</a></li>
					 <li><a href="#">Legal</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
</footer>