<?php $__env->startSection("content"); ?>
 
<?php echo $__env->make("_particles.header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

 <div class="container margin_60">



  <div class="row">
    <div class="col-md-3">

    </div>  
    <div class="col-md-6">
         <div class="main_title">
      		<h1 style="font-size: 128px;font-weight: 800;">404!</h4>      
    	</div>
      </div>
      <!-- End col-md-6 -->


     
        
  </div>
  <!-- End row -->   


   
</div>  

<?php $__env->stopSection(); ?>

<?php echo $__env->make("app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>