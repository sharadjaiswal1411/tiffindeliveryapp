<?php $__env->startSection("content"); ?>
 
<section>
   <div class="text-center featured-area light-bg padding-big" id="feature">
      <div class="container">
         <div class="row">
            <div class="col-md-3 col-sm-6 gray-border red-hover white-bg">
               <div class="featured-item">
                  <i class="icofont circled-icon icofont-tools-alt-2"></i>
                  <h3>Cross Platfrom</h3>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
               </div>
            </div>
            <div class="col-md-3 col-sm-6 gray-border red-hover white-bg">
               <div class="featured-item">
                  <i class="icofont circled-icon icofont-rocket-alt-1"></i>
                  <h3>Fast Performance</h3>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
               </div>
            </div>
            <div class="col-md-3 col-sm-6 gray-border red-hover white-bg">
               <div class="featured-item">
                  <i class="icofont circled-icon icofont-diamond"></i>
                  <h3>Clean Design</h3>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
               </div>
            </div>
            <div class="col-md-3 col-sm-6 gray-border red-hover white-bg">
               <div class="featured-item">
                  <i class="icofont circled-icon icofont-live-support"></i>
                  <h3>24/7 Live Support</h3>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
          
<section>
   <div class="padding-big app-overview-area" id="overview">
      <div class="container">
         <div class="row text-center">
            <div class="col-sm-8 col-sm-offset-2">
               <div class="section-heading mb-40">
                  <h2 class="section-title title-border">How it works</h2>
                  <p>We keep it SHORT & SIMPLE!</p>
				  <p><b>Now homemade food is just a tap away!</b></p>
				  

               </div>
            </div>
         </div>
         <div class="row flexbox-center xs-no-flexbox">
            <div class="col-md-4">
               <div class="app-overview-lists app-lists-left text-right">
                  <ul>
                     <li class="clearfix">
                        <div class="pull-right app-overview-icon"><i class="icofont circled-icon icofont-alarm"></i></div>
                        <div class="pull-left app-overview-content">
                           <h3>SEARCH WITHIN THE RANGE OF 3 KMS FROM YOUR LOCATION ></h3>
                          
                        </div>
                     </li>
                     <li class="clearfix">
                        <div class="pull-right app-overview-icon"><i class="icofont circled-icon icofont-battery-full"></i></div>
                        <div class="pull-left app-overview-content">
                           <h3>CHOOSE FROM THE BEST GIVEN OPTIONS >
</h3>
                         
                        </div>
                     </li>
                     <li class="clearfix">
                        <div class="pull-right app-overview-icon"><i class="icofont circled-icon icofont-check"></i></div>
                        <div class="pull-left app-overview-content">
                           <h3>PAY AS PER YOUR CONVENIENCE ></h3>
                          
                        </div>
                     </li>
                  </ul>
               </div>
            </div>
            <div class="col-md-4">
               <div class="text-center app-overiew-photo pb-45 pt-45"><img alt="iPhone" src="/upload/<?php echo e(getcong('home_slide_image2')); ?>" class="center-block img-responsive"></div>
            </div>
            <div class="col-md-4">
               <div class="app-overview-lists app-lists-right">
                  <ul>
                     <li class="clearfix">
                        <div class="pull-left app-overview-icon"><i class="icofont circled-icon icofont-gears"></i></div>
                        <div class="pull-right app-overview-content">
                           <h3>ENJOY THE FOOD >
</h3>
                         
                        </div>
                     </li>
                     <li class="clearfix">
                        <div class="pull-left app-overview-icon"><i class="icofont circled-icon icofont-image"></i></div>
                        <div class="pull-right app-overview-content">
                           <h3>REPEAT OR SUBSCRIBE THE PLAN!</h3>
                          
                        </div>
                     </li>

                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section>
   <div class="padding-big light-bg " id="users">
      <div class="container" style="background:#fff">
         <div class="row text-center">
            <div class="col-sm-8 col-sm-offset-2">
               <div class="section-heading mb-50">
                  <h2 class="section-title title-border"><?php echo e(getcong_widgets('about_title')); ?> </h2>
                    <?php echo getcong_widgets('about_desc'); ?>

               </div>
            </div>
         </div>
		        
      </div>
      </div>
   </div>
</section>	

<section>
   <div class="padding-big screenshots-area" id="screenshort">
      <div class="container">
         <div class="row text-center">
            <div class="col-sm-8 col-sm-offset-2">
               <div class="section-heading mb-65">
                  <h2 class="section-title title-border"><?php echo e(getcong_widgets('footer_widget1_title')); ?></h2>
                 <div class="faq-content text-left" >
				 
				<?php echo getcong_widgets('footer_widget1_desc'); ?>

				 </div>
               </div>
            </div>
         </div>
    
	 </div>
   </div>
</section>	

<section>
   <div class="app-download-area light-bg" id="download">
      <div class="container">
         <div class="row">
            <div class="col-md-6 col-md-offset-1 col-sm-7">
               <div class="xs-text-center app-download-content sm-no-margin">
                  <h2>Get <strong class="primary-color">Application</strong> Now!</h2>
                  <h5>It is <strong class="primary-color">free</strong> and you will love it.</h5>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <div class="clearfix btn-set download-btn"><a href="#"><img alt="Apple Store" src="/front/img/demo-1/apple-store.png"> </a><a href="#"><img alt="Apple Store" src="/front/img/demo-1/play-store.png"></a></div>
               </div>
            </div>
            <div class="col-sm-5 hidden-xs">
               <div class="app-download-photo"><img alt="iPhone" src="/upload/<?php echo e(getcong('home_slide_image3')); ?>"></div>
            </div>
         </div>
      </div>
   </div>
</section>  
		  
<?php $__env->stopSection(); ?>

<?php echo $__env->make("app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>