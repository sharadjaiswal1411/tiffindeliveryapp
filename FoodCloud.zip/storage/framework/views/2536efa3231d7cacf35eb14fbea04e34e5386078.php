<?php $__env->startSection("content"); ?>

<div id="main">
	<div class="page-header">
		<h2> <?php echo e(isset($promo->code) ? 'Edit: '. $promo->code : 'Add PromoCode'); ?></h2>
		
		<a href="<?php echo e(URL::to('admin/promocodes')); ?>" class="btn btn-default-light btn-xs"><i class="md md-backspace"></i> Back</a>
	  
	</div>
	<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
	<?php endif; ?>
	 <?php if(Session::has('flash_message')): ?>
				    <div class="alert alert-success">
				    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">&times;</span></button>
				        <?php echo e(Session::get('flash_message')); ?>

				    </div>
	<?php endif; ?>
   
   	<div class="panel panel-default">
            <div class="panel-body">
			<?php $promo_id=isset($promo->code) ? $promo->id : '';
			?>
                <?php echo Form::open(array('url' => array('admin/promocodes/'.$promo_id),'class'=>'form-horizontal padding-15','name'=>'menu_form','id'=>'menu_form','role'=>'form','method'=>'post')); ?> 
                
                
                <input type="hidden" name="id" value="<?php echo e(isset($promo->id) ? $promo->id : null); ?>">
                
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">No of Promo Code</label>
                      <div class="col-sm-9">
                        <input type="number" name="no_of_coupans" value="<?php echo e(isset($promo->code) ? $promo->code : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Reward or discount amt.</label>
                      <div class="col-sm-9">
                        <input type="number" name="reward" value="<?php echo e(isset($promo->reward) ? $promo->reward : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Description</label>
                      <div class="col-sm-9">
                         
                      <textarea placeholder="Description" class="form-control" name="desc" rows="3">
					  <?php if(isset($promoDesc)): ?><?php echo e($promoDesc); ?><?php endif; ?>
					  </textarea>
                    </div>
                </div>
				<div class="form-group">
                    <label for="" class="col-sm-3 control-label">Type</label>
                      <div class="col-sm-9">
                         
                      <input type="radio" name="type" value="flat" <?php if(isset($promotype)): ?><?php echo e(($promotype=='flat'
) ? "checked" : null); ?> <?php endif; ?>  />
					  Flat.
					  <input type="radio" name="type" value="percentage" <?php if(isset($promotype)): ?> <?php echo e(($promotype=='percentage'
) ? "checked" : null); ?> <?php endif; ?>  />
					  Percentage.
                    </div>
				 </div>
				<div class="form-group">
                    <label for="" class="col-sm-3 control-label">Is Disposable</label>
                      <div class="col-sm-9">
                         
                      <input type="checkbox" name="is_disposable"  <?php echo e(isset($promo->is_disposable
) ? "checked" : null); ?> />
					  *Check if code is allowed to be used once.
                    </div>
                </div>
     			<div class="form-group">
                    <label for="" class="col-sm-3 control-label">Expire at</label>
                      <div class="col-sm-9">
                        <input type="text" name="expires_at" value="<?php echo e(isset($promo->expires_at
) ? $promo->expires_at
 : null); ?>" class="form-control datepicker"> 
                  
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-offset-3 col-sm-9 ">
                    	<button type="submit" class="btn btn-primary"><?php echo e(isset($promo->id) ? 'Edit PromoCode ' : 'Add Promocode'); ?></button>
                         
                    </div>
                </div>
                
                <?php echo Form::close(); ?> 
            </div>
        </div>
   
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.admin_app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>