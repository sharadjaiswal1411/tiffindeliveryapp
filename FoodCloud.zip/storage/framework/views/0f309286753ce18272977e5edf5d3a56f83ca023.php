<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $__env->yieldContent('head_title', getcong('site_name')); ?></title>
<meta name="viewport"content="width=device-width, initial-scale=1.0">
<meta name="description" content="<?php echo $__env->yieldContent('head_description', getcong('site_description')); ?>" />

<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo $__env->yieldContent('head_title',  getcong('site_name')); ?>" />
<meta property="og:description" content="<?php echo $__env->yieldContent('head_description', getcong('site_description')); ?>" />
<meta property="og:image" content="<?php echo $__env->yieldContent('head_image', url('/upload/logo.png')); ?>" />
<meta property="og:url" content="<?php echo $__env->yieldContent('head_url', url('/')); ?>" />
<!-- Favicons-->
	<link rel="shortcut icon" href="<?php echo e(URL::asset('upload/'.getcong('site_favicon'))); ?>" type="image/x-icon">
<!--MAIN STYLE-->
            <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700"rel="stylesheet">
			<link href="<?php echo e(URL::asset('front/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
            <link href="<?php echo e(URL::asset('front/css/icofont.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(URL::asset('front/css/animate.css')); ?>" rel="stylesheet">
            <link href="<?php echo e(URL::asset('front/css/owl.carousel.min.css')); ?>" rel="stylesheet">
			<link href="<?php echo e(URL::asset('front/css/common.css')); ?>" rel="stylesheet">
			<link href="<?php echo e(URL::asset('front/css/style-1.css')); ?>" rel="stylesheet">
			<link href="<?php echo e(URL::asset('front/css/responsive-1.css')); ?>" rel="stylesheet">
			<link href="<?php echo e(URL::asset('front/css/style.css')); ?>" rel="stylesheet">           
            <script src="<?php echo e(URL::asset('front/js/modernizr-2.8.3-respond-1.4.2.min.js')); ?>"></script>
          

<?php echo getcong('site_header_code'); ?>


</head>
<body> 
	
	 	<?php echo $__env->make("_particles.header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
	 	
	 	<?php echo $__env->yieldContent("content"); ?>
	 	
	 	<?php echo $__env->make("_particles.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	
	 

<script src="<?php echo e(URL::asset('front/js/jquery.2.1.1.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('front/js/bootstrap.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('front/js/particles.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('front/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('front/js/jquery.magnific-popup.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('front/js/jquery.easypiechart.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('front/js/wow.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('front/js/common.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('front/js/own-menu.js')); ?>"></script>  
<script src="<?php echo e(URL::asset('front/js/main-1.js')); ?>"></script> 


</body>
</html>