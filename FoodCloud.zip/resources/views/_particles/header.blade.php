<div class=preloader>
                  <div class=spinner></div>
</div>
 <header class=main-header>
                  <nav class="navbar navbar-fixed-top transition" data-offset-top=100 data-spy=affix>
                     <div class=container>
                        <div class=navbar-header>
                           <a href="#" class="pull-right nav-trigger"id=nav-trigger><i class="icofont icofont-justify-all"></i></a>
                           <div class="pull-left logo"><a href="/"><img alt="App Landing Page" src="/upload/{{getcong('site_logo')}}"></a></div>
                        </div>
                        <div class="collapse navbar-collapse" id="navigation">
                           <ul class="nav navbar-nav navbar-right">
                              <li class=active><a href="#home">Home</a></li>
                              <li><a href="#feature">Feature</a></li>
                              <li><a href="#overview">Overview</a></li>
                              <li><a href="#users">About Us</a></li>
                              <li><a href="#screenshort">FAQ's</a></li>
                              <li><a href="#download">Download</a></li>
                            
                           </ul>
                        </div>
                     </div>
                  </nav>
                  <div class="particles-js" id="particle-1"></div>
                  <section>
                     <div class="bg-img home-banner" id="home">
                        <div class="container">
                           <div class="row">
                              <div class="col-md-6 hidden-sm hidden-xs">
                                 <div class=banner-image><img alt="App Landing Page" src="/upload/{{getcong('home_slide_image1')}}"></div>
                              </div>
                              <div class="col-md-6">
                                 <div class="banner-text pl-70 sm-text-center">
                                    <h1><strong>Order</strong>  Delicious Food  <strong>Online</strong></h1>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
                                    <div class="btn-set"><a href="#" class="btn btn-round btn-transparent"><i class="icofont icofont-brand-apple"></i>Apple Store</a> <a href="#" class="btn btn-round btn-transparent"><i class="icofont icofont-brand-android-robot"></i>Play Store</a></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section>
               </header>